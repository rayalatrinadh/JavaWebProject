package com.trinadh.spring.jee;

import org.springframework.stereotype.Service;

@Service
public class LoginService {
	public boolean validateUser(String user, String password) {
		/**
		 * @see as of now it's hardcoded. actual checking happens via the dataset of database ...
		 */
		return user.equalsIgnoreCase("trinadh") && password.equals("rayala");
	}

}