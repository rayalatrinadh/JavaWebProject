package com.trinadh.spring.todo;




import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;



@Controller
public class TodoController {
	
	@Autowired
	TodoService todoService;

	
	@RequestMapping(value = "/list-todos", method = RequestMethod.GET)
	public String todoList(ModelMap model) {
		model.addAttribute("todos",todoService.retrieveTodos("trinadh"));
		return "list-todos";
	}
	
	
	@RequestMapping(value = "/add-todo", method = RequestMethod.GET)
	public String showtodoList(ModelMap model) {
		
		//used to bing with commandName in todo.jsp : commandName="todo" >
		model.addAttribute("todo",new Todo(0,"trinadh","helloDesc",new Date(),false));
		return "todo";
	}
	
	@RequestMapping(value = "/add-todo", method = RequestMethod.POST)
	public String addtodoList(ModelMap model,@Valid Todo todo, BindingResult result) {
		
		if(result.hasErrors()) {
			return "todo";
		}
		model.clear();
		todoService.addTodo("trinadh", todo.getDesc(), new Date(), false);
		return "redirect:list-todos";
	}
	
	@RequestMapping(value = "/update-todo", method = RequestMethod.GET)
	public String updateTodoList(ModelMap model, @RequestParam int id) {
		System.out.println("id: " + id);
		Todo todo = todoService.retrieveTodo(id);
		model.addAttribute("todo",todo);
	//need to do delete here 
		return "todo";
	}
	
	
	@RequestMapping(value = "/update-todo", method = RequestMethod.POST)
	public String updateTodoList() {
		return "redirect:list-todos";
	}

	//delete-todo
	@RequestMapping(value = "/delete-todo", method = RequestMethod.GET)
	public String deletetodoList(ModelMap model, @RequestParam int id) {
		System.out.println("id: " + id);
		todoService.deleteTodo(id);
	//need to do delete here 
		return "redirect:list-todos";
	}
	
	
}